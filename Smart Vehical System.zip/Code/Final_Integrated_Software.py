# File name: Final_Integrated_Software
# Project: Final Capstone Project
# Program: Embedded Systems DEvelopement
# College: Conestoga College Cammridge Campus
# Term: Fall 2021
# Date: December 8th, 2021
# Students: Tayeb, Rohan, Bargav
# Professor: Ralph Stacey

"""
    The program contains three sections, one of them is chosen only. The sections are for:
    1 - test the mobile car for straight motion without balancing the wheels and so not using the encoding reading
    2 - test the mobile car for straight motion with balancing the wheels using the encoding reading
    3- test the car to avoid obstacles with two ultrsound sensors available, one at the front and othe on the left.
    
"""
from rpi_hardware_pwm import HardwarePWM
import time
import RPi.GPIO as GPIO
import time


from project_functions import *


#Supress warnings
GPIO.setwarnings(False)

# Use "GPIO" pin numbering
GPIO.setmode(GPIO.BCM)

#--------------------Pin Assignment----------------------------------

# Motors
# right motor
GPIO_pin2 = 13
GPIO_pin7 = 6

#left motor
GPIO_pin10 = 23
GPIO_pin15 = 24

pwm_left = HardwarePWM(0, hz=60)# pwm at pin 18
pwm_right = HardwarePWM(1, hz=60)# pwm at pin 19
pwm_right.start(100)
pwm_left.start(100)

#Encoders
right_Encd_A = 20
right_Encd_B = 21

left_Encd_A = 25 
left_Encd_B = 8

# Ultrasound range finder
#Front
GPIO_TRIGGER_Front = 2
GPIO_ECHO_Front = 3

#Left
GPIO_TRIGGER_Left = 27
GPIO_ECHO_Leftt = 22

#Leds   
yellow_led = 4
green_led = 17 # motor running

left_red_led = 10   
right_red_led = 9     

# Global variables
right_motion_data = [] # each element is atuple: (time.time(), counter)
left_motion_data = [] # each element is atuple: (time.time(), counter)
speed_data =[]
right_instant_count_speed = 0
left_instant_count_speed = 0 
right_counter = 0
left_counter = 0

# values used for test
acceler = 100/3
deceler = 100/3
desired_duty = 30
current_duty = 0

# flags
test_straight = False
test_turn = False
flag_right_turn = False
flag_left_turn = False

stop_car_flag = False

start_car = True
test_time = 0
MTRs_duty = 0

front_free = False
left_free = True
turn_right_done = False

radius_fact = 0.5
distance_to_avoid = 65

#================================================  Program start  ========================================================
    
# intializations
init_leds()
init_motors()
init_encoders()
init_detection()


# Program sections flags
test_straight_No_Balance = False # True #
test_straight_with_Balance = False #False
test_avoid_obstacle = True # True
 #  ==================================================  main ================================================================
if __name__ == "__main__":
    """
        One of the flags for the program sections has to be True to run 

    """
    if test_straight_No_Balance and test_straight_with_Balance:
        input("Wrong entering")
        exit()
    if test_straight_No_Balance and test_avoid_obstacle:
        input("Wrong entering")
        exit()
    if test_straight_with_Balance and test_avoid_obstacle:
        input("Wrong entering")
        exit()
    if test_straight_No_Balance and test_straight_with_Balance and test_avoid_obstacle :
        input("Wrong entering")
        exit()
    # ----------------------------------------test_straight_no_Balance------------------------------------------------     
    if test_straight_No_Balance :
        print("test_straight_No_Balance starts")
        MTRs_duty = accelerate_to_speed(acceler, desired_duty)
        test_straight = True
        start_time= time.time()
        reds_off()
        yellow_off()
        green_off()
        while True:
        
            if ( not test_straight and not test_turn_left and not test_turn_right):
                break
           
            
            
            if test_straight and (not detect_obstacle(GPIO_TRIGGER_Front, GPIO_ECHO_Front, 30)) :
                green_on()
                yellow_off()
                reds_off()
                go_forward_NoPID(MTRs_duty)
                elapsed_time = time.time()- start_time
                if elapsed_time > 30:
                    test_straight = False
                    stop_car_flag = True
                time.sleep(0.02)
       
            else :
               reds_on()
               yellow_off()
               stop_motors()
               print("Obstacle Found")
               break    
                                 
            if stop_car_flag:
                if(stop_car(deceler, MTRs_duty)):
                    reds_on()
                    break
            
            time.sleep(0.02)


        print("test_straight_No_Balance Done")
#   ----------------------------------------test_straight_with_Balance------------------------------------------------     
    elif test_straight_with_Balance :
        print("test_straight_ With_Balance starts")
        MTRs_duty = accelerate_to_speed(acceler, desired_duty)
        left_duty = MTRs_duty
        right_duty = MTRs_duty
        test_straight = True
        start_time= time.time()
        Kp = 1.5
        current_diff = 0
        prev_diff = 0
        
        inst_time = 0
        right_inst_count_speed = 0
        left_inst_count_speed = 0
        
        reds_off()
        yellow_off()
        green_off()
        
    
        while True:
           
            if ( not test_straight and not flag_left_turn and not flag_right_turn):
                break
    
            if test_straight and (not detect_obstacle(GPIO_TRIGGER_Front, GPIO_ECHO_Front, 50)) :
                time.sleep(0.3)
                green_on() 
                run_Right_MTR(right_duty, 'FWD')
                run_Left_MTR(left_duty, 'FWD')
                
                
                speed_data = get_counts_speed(speed_data)
                if len(speed_data)> 5:
                    speed_data.pop(0)                   
                    
                    inst_time = speed_data[-1][0]
                    right_inst_count_speed = speed_data[-1][1]
                    left_inst_count_speed = speed_data[-1][2]
                
                current_diff = abs(right_inst_count_speed - left_inst_count_speed)
                
                
                if abs(right_inst_count_speed - left_inst_count_speed) > 0.002:
                    if (current_diff - prev_diff) > 0.0001:
                        Kp = Kp - 0.1
                    else:
                        Kp = Kp + 0.1
                                       
                    if right_inst_count_speed > left_inst_count_speed:
                        if right_inst_count_speed != 0:
                            left_duty = Kp*left_duty * (1 + ((right_inst_count_speed - left_inst_count_speed )/ right_inst_count_speed))
                            if 1.10 * MTRs_duty < 100:
                                if left_duty > 1.10 * MTRs_duty:
                                    left_duty = 1.10 * MTRs_duty
   
                            else:
                                left_duty = 100
                        else:
                            print("error")
                    else:
                        if left_inst_count_speed != 0:
                            right_duty = Kp*right_duty * (1 + ((left_inst_count_speed - right_inst_count_speed )/ left_inst_count_speed))
                            if 1.10 * MTRs_duty < 100:
                                if right_duty > 1.10 * MTRs_duty:
                                    right_duty = 1.10 * MTRs_duty
    
                            else:
                                right_duty = 100
              
            else:
               print(" stopped to obstacle")
               stop_motors()
               break
    #        
            prev_diff = current_diff
            time.sleep(0.1)
            elapsed_time = time.time()- start_time
             
            if elapsed_time > 60:
                break
        stop_motors()
        print("test_straight With Balance Done")
        
    #   ----------------------------------------test_straight_with_Balance------------------------------------------------         
    elif test_avoid_obstacle:
        print("test_avoid_obstacle Starts")
        MTRs_duty = accelerate_to_speed(acceler, desired_duty)
        test_straight = True
        start_time= time.time()
        reds_off()
        yellow_off()
        green_off()
        
        while True:
            # execute one of them
            if ( not test_straight and not test_turn):
               
                break
           
            if test_straight:
                
                go_forward_NoPID(MTRs_duty)
                elapsed_time = time.time()- start_time
                front_free = not detect_obstacle(GPIO_TRIGGER_Front, GPIO_ECHO_Front, distance_to_avoid)
                left_free = not detect_obstacle(GPIO_TRIGGER_Left, GPIO_ECHO_Left, distance_to_avoid)
               
                time.sleep(0.3)
                if (not front_free) :
                  
                        stop_motors()
                        time.sleep(0.5)
                    
                        turn_right_done = turn_right_1(radius_fact, MTRs_duty, distance_to_avoid)
                        time.sleep(0.3)
                     

                if (distance_detect(GPIO_TRIGGER_Left, GPIO_ECHO_Left) <  50):    
                      
                        stop_motors()
                        time.sleep(0.5)
                    
                        turn_right_1(radius_fact, MTRs_duty, distance_to_avoid)
                        right_red_on()
                        time.sleep(0.3)
                      
                left_free = not detect_obstacle(GPIO_TRIGGER_Left, GPIO_ECHO_Left, distance_to_avoid)
       
                if turn_right_done:
                    
                    
                    if  left_free:
                        
                        start_time = time.time()
                        turn_time = 0
                        while turn_time < 2:
                             turn_right_done = False
                             turn_time = time.time() - start_time
                            
                             if not turn_left_free_2(turn_time,1.5,radius_fact, 40):
                                 break
                             time.sleep(0.2)
                        
                if elapsed_time > 15:
                    test_straight = False
                    stop_car_flag = True
               
            if stop_car_flag:
                if(stop_car(deceler, MTRs_duty)):
                    reds_on()
                    break
            
            time.sleep(0.02)
    
        stop_motors()
        print("test_avoid_obstacle Done")
   